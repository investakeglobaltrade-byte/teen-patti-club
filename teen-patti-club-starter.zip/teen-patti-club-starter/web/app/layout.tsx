import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'Teen Patti Club', description: 'Play • Connect • Enjoy — social card games with virtual coins.' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
