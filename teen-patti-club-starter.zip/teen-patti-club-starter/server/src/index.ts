import express from 'express';
import cors from 'cors';
import { createServer } from 'http';
import { Server } from 'socket.io';
const app=express(); app.use(cors()); app.use(express.json());
app.get('/health',(_req,res)=>res.json({ok:true,service:'teen-patti-club-demo-server',mode:'virtual-coins-only'}));
const httpServer=createServer(app);
const io=new Server(httpServer,{cors:{origin:'*'}});
io.on('connection',socket=>{
 socket.on('room:join',(roomId:string)=>{
  if(typeof roomId!=='string'||roomId.length<3||roomId.length>32)return;
  socket.join(roomId); socket.emit('room:notice',{message:`Joined demo room ${roomId}`});
 });
 socket.on('room:message',(payload:{roomId:string,message:string})=>{
  if(!payload||typeof payload.roomId!=='string'||typeof payload.message!=='string')return;
  const message=payload.message.trim().slice(0,300); if(!message)return;
  io.to(payload.roomId).emit('room:message',{message,from:'Guest',at:new Date().toISOString()});
 });
});
httpServer.listen(4000,()=>console.log('Demo server listening on :4000'));
