-- Starter schema only. Virtual coins have no cash value and cannot be purchased,
-- transferred, redeemed, or withdrawn.
CREATE TABLE app_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  display_name VARCHAR(40) NOT NULL,
  preferred_language VARCHAR(10) NOT NULL DEFAULT 'en',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  status VARCHAR(16) NOT NULL DEFAULT 'active'
);
CREATE TABLE virtual_wallets (
  user_id UUID PRIMARY KEY REFERENCES app_users(id),
  coin_balance BIGINT NOT NULL DEFAULT 0 CHECK (coin_balance >= 0),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE coin_ledger (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES app_users(id),
  delta BIGINT NOT NULL,
  reason VARCHAR(40) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE game_rooms (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  room_code VARCHAR(12) UNIQUE NOT NULL,
  game_type VARCHAR(20) NOT NULL CHECK (game_type IN ('teen_patti','rummy')),
  status VARCHAR(16) NOT NULL DEFAULT 'waiting',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE referrals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  inviter_id UUID NOT NULL REFERENCES app_users(id),
  invitee_id UUID NOT NULL REFERENCES app_users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(invitee_id)
);
