import 'package:flutter/material.dart';
void main()=>runApp(const ClubApp());
const green=Color(0xFF10251D), gold=Color(0xFFD6B45C);
class ClubApp extends StatelessWidget{
 const ClubApp({super.key});
 @override Widget build(BuildContext context)=>MaterialApp(debugShowCheckedModeBanner:false,title:'Teen Patti Club',theme:ThemeData.dark().copyWith(scaffoldBackgroundColor:green,colorScheme:ColorScheme.fromSeed(seedColor:gold,brightness:Brightness.dark)),home:const ClubHome());
}
class ClubHome extends StatefulWidget{const ClubHome({super.key});@override State<ClubHome> createState()=>_ClubHomeState();}
class _ClubHomeState extends State<ClubHome>{
 int coins=25000; int index=0;
 @override Widget build(BuildContext context){
 final pages=[home(),games(),wallet(),profile()];
 return Scaffold(appBar:AppBar(title:const Text('♠ TEEN PATTI CLUB',style:TextStyle(color:gold,fontWeight:FontWeight.bold)),backgroundColor:green,actions:[Center(child:Padding(padding:const EdgeInsets.all(12),child:Text('$coins 🪙')))]),
 body:pages[index],bottomNavigationBar:NavigationBar(backgroundColor:const Color(0xFF1B382B),selectedIndex:index,onDestinationSelected:(v)=>setState(()=>index=v),destinations:const [NavigationDestination(icon:Icon(Icons.home),label:'Home'),NavigationDestination(icon:Icon(Icons.style),label:'Games'),NavigationDestination(icon:Icon(Icons.account_balance_wallet),label:'Wallet'),NavigationDestination(icon:Icon(Icons.person),label:'Profile')]));
 }
 Widget home()=>ListView(padding:const EdgeInsets.all(18),children:[const Text('PLAY • CONNECT • ENJOY',style:TextStyle(color:gold,letterSpacing:2)),const SizedBox(height:18),gameCard('♠','Teen Patti','Classic 3-card social game • 2–6 players'),gameCard('♦','Rummy','13-card social Rummy'),const SizedBox(height:12),const Text('Virtual coins only. No cash prizes, deposits or withdrawals.',style:TextStyle(color:Colors.white70))]);
 Widget gameCard(String icon,String name,String detail)=>Card(color:const Color(0xFF1B382B),child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(icon,style:const TextStyle(fontSize:40,color:gold)),Text(name,style:const TextStyle(fontSize:22,color:gold,fontWeight:FontWeight.bold)),Text(detail),const SizedBox(height:12),FilledButton(onPressed:()=>setState(()=>index=1),child:const Text('Open practice game'))])));
 Widget games()=>ListView(padding:const EdgeInsets.all(18),children:[const Text('Practice Games',style:TextStyle(fontSize:24,color:gold)),const SizedBox(height:12),gameCard('♠','Teen Patti','Sample cards and practice table'),gameCard('♦','Rummy','Sample 13-card table preview')]);
 Widget wallet()=>Center(child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[const Text('VIRTUAL COIN BALANCE'),Text('$coins 🪙',style:const TextStyle(fontSize:32,color:gold,fontWeight:FontWeight.bold)),const Text('Demo points only — no cash value')]));
 Widget profile()=>const Center(child:Text('Guest Preview\nGoogle + OTP authentication to be integrated',textAlign:TextAlign.center));
}
