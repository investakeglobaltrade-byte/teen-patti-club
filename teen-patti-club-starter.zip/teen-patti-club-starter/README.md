# Teen Patti Club — Starter Project

A social-card-game starter for **virtual coins only**. It includes:
- Next.js web prototype (responsive, Royal Gold + Green)
- Flutter Android starter screen
- Node.js / Express + Socket.IO backend scaffold
- PostgreSQL schema starter

## Important
This is a development starter, not a production-ready or fully audited game. It does **not** implement real-money betting, cash prizes, deposits, withdrawals, coin purchases, or cash conversion. The included game screen is a UI/practice prototype with sample cards. The backend scaffold demonstrates room messaging only; it does not implement authoritative card dealing or a complete Teen Patti/Rummy rules engine.

Before public launch:
1. Obtain qualified legal review for each target jurisdiction and app-store policy review.
2. Implement server-authoritative, independently tested game rules and secure randomness.
3. Add production authentication (Google OAuth and OTP provider), moderation, abuse reporting, privacy controls, rate limiting, monitoring, backups and security testing.
4. Add age controls and responsible-play protections.
5. Do not treat demo balances or sample admin metrics as real users or funds.

## Run the website
Requirements: Node.js 20+

```bash
cd web
npm install
npm run dev
```
Open http://localhost:3000

## Run the backend scaffold
```bash
cd server
npm install
npm run dev
```
Runs on http://localhost:4000. Socket.IO event `room:join` joins a demo room and `room:message` broadcasts chat. No game state or wallet authority is implemented.

## Run the Flutter starter
Install Flutter SDK, then:
```bash
cd mobile
flutter pub get
flutter run
```
The mobile folder is a minimal Flutter starter UI. For a production app, connect it to the same API and game server as the website.

## Project layout
- `web/` — responsive Next.js app
- `server/` — Express + Socket.IO scaffold
- `mobile/` — Flutter starter
- `database/schema.sql` — starter relational schema

## Build an Android APK using GitHub Actions
This repository includes `.github/workflows/android-apk.yml`.
1. Create a GitHub repository and upload/push the contents of this project.
2. Ensure the default branch is named `main`.
3. Open the repository's **Actions** tab.
4. Select **Build Android APK** and choose **Run workflow** (or push to `main`).
5. When the workflow completes, open the run and download the `teen-patti-club-android-apk` artifact.

The generated APK is an unsigned release build suitable for internal testing; configure a secure signing key before Play Store distribution. Do not commit signing keys or passwords to the repository.
